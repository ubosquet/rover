#!/bin/bash
set -o nounset

# ZT Systems BIOS update tool
# Author: Craig Jackson (craig.jackson@ztsystems.com)
# Usage: ./update_bios.sh
# Options:
#   -n Do not prompt for anything
#   -q Quiet.  Be less verbose
#   -t Test mode. Assumes verbose
# Changelog:
# 2016/01/25 Initial Release
# 2016/11/28 Added ME Recovery Mode for ME Update and Disable/Enable SMI_Timeout 

# Global declarations
logFile="../LOG/update_bios.log"
biosImage="RoverF15_B601G3_BIOS_V4.08.27.00_NM.bin"
updateBiosCommand64="./afulnx_64 ${biosImage} /GAN"
updateBiosCommand32="./afulnx_32 ${biosImage} /GAN"
updateMeCommand64="./afulnx_64 ${biosImage} /MER /FDR /ME"
updateMeCommand32="./afulnx_32 ${biosImage} /MER /FDR /ME"
if [ "$(uname -m)" == "x86_64" ]; then
  updateBiosCommand="${updateBiosCommand64}"
  updateMeCommand="${updateMeCommand64}"
else
  updateBiosCommand="${updateBiosCommand32}"
  updateMeCommand="${updateMeCommand32}"
fi

# Gather command line parameters
switches=""
if [ $# -gt 0 ]; then
  switches="${switches} ${1}"
fi
if [ $# -gt 1 ]; then
  switches="${switches} ${2}"
fi
if [ $# -gt 2 ]; then
  switches="${switches} ${3}"
fi

# Parse command line parameters
noPrompt="no"
quiet="no"
testMode="no"
for switch in ${switches}; do
  if [ "${switch}" == "-n" ]; then
    noPrompt="yes"
  fi
  if [ "${switch}" == "-q" ]; then
    quiet="yes"
  fi
  if [ "${switch}" == "-t" ]; then
    testMode="yes"
  fi
done

# If interactive mode, check for the existence of a serial/asset cache.
# If no cache exists, prompt the user for a serial/asset and fill the cache.
if [ "${noPrompt}" == "no" ]; then
  if [ -e /tmp/ztCache.txt ]; then
    source /tmp/ztCache.txt
  else
    printf "Please enter a serial number: "
    read serial
    printf "Please enter an asset tag: "
    read asset
    echo "#!/bin/bash" > /tmp/ztCache.txt
    echo "serial=${serial}" >> /tmp/ztCache.txt
    echo "asset=${asset}" >> /tmp/ztCache.txt
  fi
fi

# Error handler
logFile="../LOG/update_bios.log"
function errorHandler
{
  if [ "${quiet}" == "yes" ]; then
    if [ "${testMode}" == "yes" ]; then
      echo "Pretending to run command:" >> ${logFile}
      echo "$@" >> ${logFile}
    else
      echo "Running command:" >> ${logFile}
      echo "$@" >> ${logFile}
      "$@" >> ${logFile} 2>&1
    fi
    status=$?
    if [ ${status} -ne 0 ]; then
      echo "$@ failed with error:" | tee -a ${logFile}
      echo "$1" | tee -a ${logFile}
      exit 1
    fi
    return $status
  else
    if [ "${testMode}" == "yes" ]; then
      echo "Pretending to run command:" | tee -a ${logFile}
      echo "$@" | tee -a ${logFile}
    else
      echo "Running command:" | tee -a ${logFile}
      echo "$@" | tee -a ${logFile}
      "$@" | tee -a ${logFile} 2>&1
    fi
    status=${PIPESTATUS[0]}
    if [ ${status} -ne 0 ]; then
      echo "$@ failed with error:" | tee -a ${logFile}
      echo "$1" | tee -a ${logFile}
      exit 1
    fi
    return $status
  fi
}

# Message handler
function messageHandler
{
        if [ "${quiet}" == "yes" ]; then
                echo "$@" >> ${logFile}
        else
                echo "$@" | tee -a ${logFile}
        fi
}

if [ "${UID}" != "0" ]; then
  messageHandler You must have root privileges when running this tool.
  exit 1
fi

messageHandler Putting ME into recovery mode for Update...
errorHandler ipmitool -b 6 -t 0x2c raw 0x2E 0xDF 0x57 0x01 0x00 0x01
messageHandler Disabling SMI_Timeout for update
errorHandler ipmitool raw 0x34 0x20 1
sleep 10

messageHandler Updating BIOS....
errorHandler ${updateBiosCommand}

if [ ${status} -eq 0 ]; then
  messageHandler BIOS update successful.
else
  messageHandler BIOS update NOT successful.
  messageHandler Please examine the log file in ${logFile} for details.
  exit 1
fi

sleep 10
messageHandler Updating ME....
errorHandler ${updateMeCommand}

sleep 10
messageHandler Restoring ME after Update...
errorHandler ipmitool -b 6 -t 0x2c raw 0x2E 0xDF 0x57 0x01 0x00 0x02
messageHandler Enabling SMI_Timeout after update
errorHandler ipmitool raw 0x34 0x20 0

if [ ${status} -eq 0 ]; then
  messageHandler ME update successful.
  messageHandler Please reboot for changes to take effect
else
  messageHandler ME update NOT successful.
  messageHandler Please examine the log file in ${logFile} for details.
fi

