#!/bin/bash
set -o nounset

# ZT Systems FRU update tool
# Author: Craig Jackson (craig.jackson@ztsystems.com)
# Usage: ./update_fru.sh
# Options:
#   -n Do not prompt for anything
#   -q Quiet.  Be less verbose
#   -t Test mode. Assumes verbose
# Changelog:
# 2016/01/25 Initial Release

# Global declarations
logFile="../LOG/update_fru.log"
fruFile="set.fru"
updateCommand64="./uh8l-1.1.3-64b --open --fru ${fruFile}"
updateCommand32="./uh8l-1.1.3 --open --fru ${fruFile}"
product="ROVERF15"
part="SR-01235-001"
boardModel="B601G3"
boardPart="1395T2729702"
if [ "$(uname -m)" == "x86_64" ]; then
  updateCommand="${updateCommand64}"
else
  updateCommand="${updateCommand32}"
fi

# Gather command line parameters
switches=""
if [ $# -gt 0 ]; then
  switches="${switches} ${1}"
fi
if [ $# -gt 1 ]; then
  switches="${switches} ${2}"
fi
if [ $# -gt 2 ]; then
  switches="${switches} ${3}"
fi

# Parse command line parameters
noPrompt="no"
quiet="no"
testMode="no"
for switch in ${switches}; do
  if [ "${switch}" == "-n" ]; then
    noPrompt="yes"
  fi
  if [ "${switch}" == "-q" ]; then
    quiet="yes"
  fi
  if [ "${switch}" == "-t" ]; then
    testMode="yes"
  fi
done

# Error handler
function errorHandler
{
  if [ "${quiet}" == "yes" ]; then
    if [ "${testMode}" == "yes" ]; then
      echo "Pretending to run command:" >> ${logFile}
      echo "$@" >> ${logFile}
    else
      echo "Running command:" >> ${logFile}
      echo "$@" >> ${logFile}
      "$@" >> ${logFile} 2>&1
    fi
    status=$?
    if [ ${status} -ne 0 ]; then
      echo "$@ failed with error:" | tee -a ${logFile}
      echo "$1" | tee -a ${logFile}
      exit 1
    fi
    return $status
  else
    if [ "${testMode}" == "yes" ]; then
      echo "Pretending to run command:" | tee -a ${logFile}
      echo "$@" | tee -a ${logFile}
    else
      echo "Running command:" | tee -a ${logFile}
      echo "$@" | tee -a ${logFile}
      "$@" | tee -a ${logFile} 2>&1
    fi
    status=$?
    if [ ${status} -ne 0 ]; then
      echo "$@ failed with error:" | tee -a ${logFile}
      echo "$1" | tee -a ${logFile}
      exit 1
    fi
    return $status
  fi
}

# Message handler
function messageHandler
{
        if [ "${quiet}" == "yes" ]; then
                echo "$@" >> ${logFile}
        else
                echo "$@" | tee -a ${logFile}
        fi
}

function fruErrorHandler
{
  if [ "${testMode}" == "no" ]; then
    messageHandler Running command:
    messageHandler $@
    "$@" > fruOutput 2>&1
    messageHandler $(cat fruOutput)
    fruOutputGrep=$(cat fruOutput | grep "fail")
    rm -f fruOutput
    if [ "${fruOutputGrep}" != "" ]; then
      messageHandler FRU update failed.  Please see the log for details
      status=1
      return 1
    else
      status=0
      return 0
    fi
  else
    messageHandler Pretending to run command:
    messageHandler $@
    status=0
    return 0
  fi
}

function dec_to_hex {
  fru_length=$((${1}+192))
  declare -r HEX_DIGITS="0123456789ABCDEF"
  dec_value=${fru_length}
  hex_value=""
  until [ $dec_value == 0 ]; do
    rem_value=$((dec_value % 16))
    dec_value=$((dec_value / 16))
    hex_digit=${HEX_DIGITS:$rem_value:1}
    hex_value="${hex_digit}${hex_value}"
  done
  echo -e "${hex_value}"
}

if [ "${UID}" != "0" ]; then
  messageHandler You must have root privileges when running this tool.
  exit 1
fi

# Make sure drivers are loaded
siLoaded=$(lsmod | grep -m 1 ipmi_si)
devintfLoaded=$(lsmod | grep -m 1 ipmi_devintf)
if [ "${siLoaded}" == "" ] || [ "${devintfLoaded}" == "" ]; then
  messageHandler Loading IPMI drivers...
fi
if [ "${siLoaded}" == "" ]; then
  modprobe ipmi_si
fi
if [ "${devintfLoaded}" == "" ]; then
  modprobe ipmi_devintf
fi
if [ "${siLoaded}" == "" ] || [ "${devintfLoaded}" == "" ]; then
  messageHandler Waiting 5 seconds for drivers to load...
  sleep 5
fi

serial=""
asset=""
# If interactive mode, check for the existence of a serial/asset cache.
# If no cache exists, prompt the user for a serial/asset and fill the cache.
if [ "${noPrompt}" == "no" ]; then
  if [ -e /tmp/ztCache.txt ]; then
    source /tmp/ztCache.txt
  else
    printf "Please enter a serial number: "
    read serial
    printf "Please enter an asset tag: "
    read asset
    echo "#!/bin/bash" > /tmp/ztCache.txt
    echo "serial=${serial}" >> /tmp/ztCache.txt
    echo "asset=${asset}" >> /tmp/ztCache.txt
  fi
fi

boardSerial=$(ipmitool fru | grep -m 1 "Board Serial" | awk '{print $4}')
if [ "${noPrompt}" == "yes" ]; then
  serial=$(ipmitool fru | grep -m 1 "Chassis Serial" | awk '{print $4}')
  asset=$(ipmitool fru | grep -m 1 "Product Asset Tag" | awk '{print $5}')
fi

# Determine the length of each of the dynamic fields
boardModelLength="${#boardModel}"
boardPartLength="${#boardPart}"
productLength="${#product}"
serialLength="${#serial}"
assetLength="${#asset}"
partLength="${#part}"
boardSerialLength="${#boardSerial}"
if [ "${boardSerial}" = "" ]; then
  board_serial_length="0"
fi

# Convert the above lengths to a hex value that can be used in the FRU text file below
boardModelHex="$(dec_to_hex ${boardModelLength})"
boardPartHex="$(dec_to_hex ${boardPartLength})"
productHex="$(dec_to_hex ${productLength})"
serialHex="$(dec_to_hex ${serialLength})"
assetHex="$(dec_to_hex ${assetLength})"
partHex="$(dec_to_hex ${partLength})"
boardSerialHex="$(dec_to_hex ${boardSerialLength})"

# Generate the FRU text file to be later written using uh8l
echo "_FRU" > set.fru
echo "" >> set.fru
echo "_FRU_TITLE '(null)'" >> set.fru
echo "_DATA_LEN 0000" >> set.fru
echo "_DEV_ACCESS_ADDR 00" >> set.fru
echo "_DEV_SLAVE_ADDR 00" >> set.fru
echo "_DEV_ID 00" >> set.fru
echo "_DEV_ACCESS_LUN 00" >> set.fru
echo "_BUS_ID 00" >> set.fru
echo "" >> set.fru
echo "_SEE_COMMON" >> set.fru
echo "   01" >> set.fru
echo "   01" >> set.fru
echo "   0B" >> set.fru
echo "   13" >> set.fru
echo "   1B" >> set.fru
echo "   00" >> set.fru
echo "   00" >> set.fru
echo "   C5" >> set.fru
echo "" >> set.fru
echo "_SEE_INTERNAL" >> set.fru
echo "   00" >> set.fru
echo "" >> set.fru
echo "_SEE_CHASSIS" >> set.fru
echo "   01" >> set.fru
echo "   08" >> set.fru
echo "   17" >> set.fru
echo "   ${partHex}" >> set.fru
echo "   '${part}'" >> set.fru
echo "   ${serialHex}" >> set.fru
echo "   '${serial}'" >> set.fru
echo "   C8" >> set.fru
echo "   'ZTSYSTEM'" >> set.fru
echo "   C1" >> set.fru
echo "   CC" >> set.fru
echo "" >> set.fru
echo "_SEE_BOARD" >> set.fru
echo "   01" >> set.fru
echo "   08" >> set.fru
echo "   00" >> set.fru
echo "   F0 87 9C" >> set.fru
echo "   C8" >> set.fru
echo "   'ZTSYSTEM'" >> set.fru
echo "   ${boardModelHex}" >> set.fru
echo "   '${boardModel}'" >> set.fru
echo "   ${boardSerialHex}" >> set.fru
echo "   '${boardSerial}'" >> set.fru
echo "   ${boardPartHex}" >> set.fru
echo "   '${boardPart}'" >> set.fru
echo "   C0" >> set.fru
echo "   C1" >> set.fru
echo "   B7" >> set.fru
echo "" >> set.fru
echo "_SEE_PRODUCT" >> set.fru
echo "   01" >> set.fru
echo "   11" >> set.fru
echo "   00" >> set.fru
echo "   C8" >> set.fru
echo "   'ZTSYSTEM'" >> set.fru
echo "   ${productHex}" >> set.fru
echo "   '${product}'" >> set.fru
echo "   ${partHex}" >> set.fru
echo "   '${part}'" >> set.fru
echo "   C3" >> set.fru
echo "   '1.0'" >> set.fru
echo "   ${serialHex}" >> set.fru
echo "   '${serial}'" >> set.fru
echo "   ${assetHex}" >> set.fru
echo "   '${asset}'" >> set.fru
echo "   C0" >> set.fru
echo "   C1" >> set.fru
echo "   16" >> set.fru

fruErrorHandler ${updateCommand}
status=$?

if [ -f set.fru ]; then
  rm set.fru
fi

if [ ${status} -eq 0 ]; then
  messageHandler FRU update successful.
  messageHandler Please reboot for changes to take effect
else
  messageHandler FRU update NOT successful.
  messageHandler Please examine the log file in ${logFile} for details.
fi

